#include <iostream>
using namespace std;

int main(){
    int a=2.1;
    float b=2.1;
    if(a==b) cout<<"Equal"<<endl;
    else cout<<"Not Equal"<<endl;
    return 0;
}